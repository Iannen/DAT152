const rootElement = document.getElementById("root");

const element = rootElement.querySelector("h1:first-child");

console.log(`Element has tag ${element.tagName}`)