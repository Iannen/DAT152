const rootElement = document.getElementById("root");

console.log(`Element has tag ${rootElement.tagName}`)