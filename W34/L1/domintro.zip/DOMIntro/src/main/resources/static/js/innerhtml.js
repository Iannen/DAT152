const rootElement = document.getElementById("root");

rootElement.innerHTML = "<h1>Welcome to DAT152</h1>";

//rootElement.textContent = "<h1>Welcome to DAT152</h1>";
//document.body.textContent = "";