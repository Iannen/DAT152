const rootElement = document.getElementById("root");

rootElement.insertAdjacentHTML("beforeend","<h1>Welcome to DAT152</h1>");