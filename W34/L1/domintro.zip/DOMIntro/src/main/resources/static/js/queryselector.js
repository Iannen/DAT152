const element = document.querySelector("h1:first-child");

console.log(`Element has tag ${element.tagName}`)