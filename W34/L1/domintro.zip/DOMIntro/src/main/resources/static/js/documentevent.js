document.addEventListener("DOMContentLoaded",
	() => { console.log("Document is now in browser memory") }
);