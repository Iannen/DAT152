package no.hvl.dat152.js;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DomIntroApplication {

	public static void main(String[] args) {
		SpringApplication.run(DomIntroApplication.class, args);
	}

}
