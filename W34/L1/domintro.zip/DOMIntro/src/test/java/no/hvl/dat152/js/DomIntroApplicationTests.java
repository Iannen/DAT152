package no.hvl.dat152.js;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomIntroApplicationTests {

	@Test
	void contextLoads() {
	}

}
