/**
 * 
 */
package no.hvl.dat152.security.model;

public enum Role {
	ADMIN,
	USER
}
