INSERT INTO workorganizer.task (title,status) VALUES ('Paint roof','WAITING');
INSERT INTO workorganizer.task (title,status) VALUES ('Wash windows','ACTIVE');
INSERT INTO workorganizer.task (title,status) VALUES ('Wash floor','DONE');