# Preexisting

URL to application:
http://127.0.0.1:8080/TaskList/
Observe that currently there is no content in the component. You must
create the code of the component.

URL to demo:
http://127.0.0.1:8080/TaskList/demo/index.html

URL to the in-memory database of the application:
http://localhost:8080/TaskList/h2-console
 
# Log

## 1.9
Kom bra i gang med ex3/oblig1. Må få satt opp task list med callbacks fra taskview controller for at det skal funke.

edit: må få taskbox til å funke - det er en modal som må trigges og noe sånt

## 5.9
Nesten ferdig nå. Laget en egen API klasse for å sentralisere fetch greier.

TODO: fikse det sånn at task-box har fresh state hver gang den åpnes.
TODO: Kanskje fikse litt layout of noe CSS og slikt

Tror det er i mål egentlig.