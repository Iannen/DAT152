URL to application:
http://127.0.0.1:8080/TaskList/
Observe that currently there is no content in the component. You must
create the code of the component.

URL to demo:
http://127.0.0.1:8080/TaskList/demo/index.html

URL to the in-memory database of the application:
http://localhost:8080/TaskList/h2-console