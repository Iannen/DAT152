package no.hvl.dat152.database;

public class DatabaseSettings {
  static final String source = "java:comp/env/jdbc/DAT152"; 
}
